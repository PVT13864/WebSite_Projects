<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Data Type:Boolean</title>
</head>
<body>
    <div class="container">
    <h1>Data Type Boolean</h1>
    <div>
        <?php
        $boolVar1=(4<6);
        var_dump($boolVar1);
        echo "<br>";
        $boolVar2=(4>9);
        var_dump($boolVar2);
        echo "<br>";
        $boolVar3=$boolVar1 && $boolVar2;
        var_dump($boolVar3);
        echo "<br>";
        $boolVar4=$boolVar1 || $boolVar2;
        var_dump($boolVar4);
        echo "<br>";
        
        var_dump(!$boolVar1);
        ?>
    </div>
    </div>
</body>
</html>