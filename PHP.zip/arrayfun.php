<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Array Functions</title>
</head>
<body>
    <div class="container">
    <h1>Array Functions</h1>
    <div>
        <?php 
        $cars=array("Tata","Mahindra","Force","Maruti");
        rsort($cars);
        $len=count($cars);
        for($i=0;$i<$len;$i++)
        {
            echo "$cars[$i] <br>";
        }
        $num=array(5,8,4,9);
        rsort($num);
        $len=count($num);
        for($i=0;$i<$len;$i++)
        {
            echo "$num[$i] <br>";
        }
        $age=array("Ram"=>"44","Ramesh"=>"24","Amit"=>"45",);
        arsort($age);
        foreach($age as $x=>$value)
        {
            echo "key= $x , Value= $value <br>";
        }
        ?>
    </div>
    </div>
</body>
</html>