

<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Courgette|Pacifico:400,700">
        <title>JSON in PHP</title>
       <style> 
       html{
        position: relative;
        min-height: 100%;
       }
    </style>
    </head>
    <body>
        <div class="container mt-5">
            <?php
                include "header.php";
                
            ?>
                        <div class="border border-success rounded p-3 mt-5 w-50">
                    <h3 class="text-primary text-center">JSON in PHP</h3>
                    <?php
                        $age=array("Ram"=>21,"Sham"=>33,"Ravi"=>45);
                        $cars=array("Tata","Mahindra","Maruti");
                        echo json_encode($age);
                        echo json_encode($cars);
                        $jsonobj='{"Kanta":13,"Seeta":14,"Mansi":16}';
                        echo "<br>";
                        var_dump(json_decode($jsonobj));
                        echo "<br>";
                        $ob=json_decode($jsonobj);
                        echo $ob->Kanta;
                        echo "<br>";
                        echo $ob->Seeta;
                        echo "<br>";
                        foreach($ob as $key=>$value)
                        {
                            echo $key . "=>" . $value . "<br>";
                        }
                    ?>
                </div>
                <?php
                include "footer.php";
            ?> 
        </div>
        <!-- JavaScript Bundle with Popper -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    </body>
</html>