
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Courgette|Pacifico:400,700">
        <title>File Handling in PHP</title>
        
    </style>
    </head>
    <body>
        <div class="container ">
            <h1 class="text-center">File Handling in PHP</h1>
                <div class="border border-success rounded p-3">
                    <h3 class="text-primary">Read file using the readfile() function:</h3>
                        <?php
                            echo readfile("Sample.txt");
                        ?>
                    <h3 class="text-secondry">fopen/fclose functions:</h3>
                        <?php
                            if(file_exists("sample1.txt"))
                            {
                                $myFile=fopen("sample1.txt","r");
                                fclose($myFile);
                            }
                            else
                            {
                                echo '<p> This file not exists</P>';
                            }
                        ?>
                    <h3 class="text-success">fread Function </h3>
                        <?php
                            $fileHandle=fopen("sample.txt","r") or die("Unable to open file");
                            $fileContent=fread($fileHandle,filesize("sample.txt"));
                            fclose($fileHandle);
                            var_dump($fileContent);
                        ?>
                    <h3 class="text-info">fgets and fgetc function</h3>
                    <?php
                        $myFile=fopen("sample.txt","r") or die("Unable to open file");
                        echo fgetc($myFile);
                        fclose($myFile);
                        echo "<br>";
                    ?>
                    <?php
                        $myFile=fopen("sample.txt","r") or die("Unable to open file");
                        echo fgets($myFile);
                        echo "<br>";
                        fclose($myFile);
                    ?>
                    
                    <h3 class="text-warning"> feof() Function</h3>
                    <?php
                        $myFile=fopen("sample.txt","r") or die("Unable to open file");
                        //Output one char at time till end of file
                        while(!feof($myFile))
                        {
                            echo fgetc($myFile);
                        }
                        
                        fclose($myFile);
                        echo "<br>";
                    ?>
                    <?php
                        $myFile=fopen("sample.txt","r") or die("Unable to open file");
                        while(!feof($myFile))
                        {
                            echo fgets($myFile) . "<br>";
                        }
                        fclose($myFile);
                    ?>        
                    <h3 class="text-danger">File Function</h3>
                    <?php
                        $fileContent=file("Sample.txt") or die("File is not there");
                        var_dump($fileContent);
                        echo "<br>";
                        foreach($fileContent as $line)
                        {
                            echo $line . "<br>";
                        }
                    ?>     
                    <h3 class="text-dark">fwrite function</h3>
                    <?php
                        $myFile=fopen("newFile.txt","w") or die("Unbale to open file");
                        $txt="My name Ram\n";
                        fwrite($myFile,$txt);
                        $txt="My name Krishan\n";
                        fwrite($myFile,$txt);
                        fclose($myFile);
                    ?>
                     <?php
                        $myFile=fopen("newFile.txt","a") or die("Unbale to open file");
                        $txt="My name Rani\n";
                        fwrite($myFile,$txt);
                        $txt="My name Krishana\n";
                        fwrite($myFile,$txt);
                        fclose($myFile);
                    ?>
                </div>
        </div>
        <!-- JavaScript Bundle with Popper -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    </body>
</html>