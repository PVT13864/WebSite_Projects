<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Functions:String Function</title>
</head>
<body>
    <div class="container">
    <h1>String Function</h1>
    <div>
        <?php
        $message="Welcome to my course.In this course you will learn Web Development";
        echo "Length of String= ". strlen($message) ." Characters";
        echo "<br>";
        echo "Number of Words= " . str_word_count($message) . " Words";
        echo "<br>";
        echo str_replace("course","website",$message,$word_replased);
        echo "<br>";
        echo "Number of words replaced= " . $word_replased . " Words";
        echo "<br>";
        echo $message;
        echo "<br>";
        echo strpos($message,"this");
        echo "<br>";
        echo "Reverse String= " . strrev($message);
        ?>
    </div>
    </div>
</body>
</html>