<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Create table in database using PHP</title>
</head>
<body>
    <div class="container text-center">
        <h1>Create table in database using PHP</h1>
        <?php
        $server="localhost";
        $user="root";
        $pw="";
        $DB="mydata";
        //create connection
            $con=new mysqli($server,$user,$pw,$DB);
            //check connection
            if($con->connect_error)
            {
                die("Connection Fail" . $con->connect_error);
            }
            echo '<div class="alert alert-success">Connection Successfull</div>';
            //create database
            $sql="CREATE TABLE Users (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                firstname VARCHAR(30) NOT NULL,
                lastname VARCHAR(30) NOT NULL,
                email VARCHAR(20) NOT NULL,
                passwd VARCHAR(10) NOT NULL
            )";
            if($con->query($sql)===true)
            {
                echo '<div class="alert alert-success">Table created  Successfully</div>';
            }
            else
            {
                echo '<div class="alert alert-danger">Error creating table' . $con->connect_error . '</div>';
            }
            $con->close();
            echo '<div class="alert alert-danger">Connection closeed</div>';
        ?>
    </div>
</body>
</html>