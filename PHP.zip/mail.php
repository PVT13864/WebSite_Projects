<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>PHP Send Mail</title>
</head>
<body>
    <div class="container">
    <h1>Send Mail</h1>
    <div>
        <?php 
        $to="parm@parminderpatial.tech";
        $subject="Here an offer for you";
        $msg="Learn Web developemnt with 50% off on total fee ";
        $result=mail($to,$subject,$msg);
        if($result)
        {
            echo "Message sent";
        }
        else
        {
            echo "Message not sent";
        }
        ?>
       
    </div>

</div>
    </div>
</body>
</html>