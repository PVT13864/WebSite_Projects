<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Retrieve Data into HTML</title>
</head>
<body>
    <div class="container text-center border rounded border-primary border-3 mt-5">
        <h1>Retrieve Data into HTML</h1>
        <h1 class="text-warning">Connecting to database</h1>
        <div>
        <?php
            $server="localhost";
            $user="root";
            $pw="";
            $DB="mydata";
            //create connection
                $con=new mysqli($server,$user,$pw,$DB);
                //check connection
                if($con->connect_error)
                {
                    die("Connection Fail" . $con->connect_error);
                }
                echo '<div class="alert alert-success">Connection Successfull</div>';
                
        ?> 
        </div>
        <div>
            <h1 class="text-info">Retrieve Data into HTML</h1>
          <?php
            //$sql="SELECT * FROM users";
            //$sql="SELECT * FROM users WHERE lastname='Kumar'";
            $sql="SELECT * FROM users ORDER BY firstname DESC";
            if($result=mysqli_query($con,$sql))
            {
                // print_r($result);
                // echo "<br>";
                if(mysqli_num_rows($result)>0)
                {
                    // print_r(mysqli_fetch_array($result,MYSQLI_ASSOC));
                    // echo "<br>";
                    // print_r(mysqli_fetch_array($result,MYSQLI_ASSOC));
                    // echo "<br>";
                    // print_r(mysqli_fetch_array($result,MYSQLI_ASSOC));
                    // echo "<br>";
                    // print_r(gettype(mysqli_fetch_array($result,MYSQLI_ASSOC)));
                    echo "<table class='table table-striped table-hover table-bordered table-condensed'>
                    <tr>
                    <th>ID</th>
                    <th>FirstName</th>
                    <th>LastName</th>
                    <th>Email ID</th>
                    <th>Password</th>
                    </tr>";
                    while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
                    {
                        // print_r($row);
                        // echo "<br>";
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["firstname"] . "</td>";
                        echo "<td>" . $row["lastname"] . "</td>";
                        echo "<td>" . $row["email"] . "</td>";
                        echo "<td>" . $row["passwd"] . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                    //close resultset
                    mysqli_free_result($result);
                }
                else
                {
                    echo "<p>No record Found</p>";
                }
            }
            else
            {
                echo "<p>Unable to Execute : $sql </p>";
            }
          ?>
       </div>
        
    </div>
</body>
</html>