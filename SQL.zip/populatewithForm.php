<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Form to Populate Table using PHP</title>
</head>
<body>
    <div class="container text-center border rounded border-primary border-3 mt-5">
        <h1>Form to Populate Table using PHP</h1>
        <h1 class="text-warning">Connecting to database</h1>
        <div>
        <?php
        $server="localhost";
        $user="root";
        $pw="";
        $DB="mydata";
        //create connection
            $con=new mysqli($server,$user,$pw,$DB);
            //check connection
            if($con->connect_error)
            {
                die("Connection Fail" . $con->connect_error);
            }
            echo '<div class="alert alert-success">Connection Successfull</div>';
            
        ?>    
        </div>
        <div>
            <h1 class="text-info">Sending Data Using Form</h1>
            <?php
                $errors=[];
                $errorMesg='';
                //get user input
                
                if(isset($_POST['submit']))
                {
                    $id=$_POST['id'];
                    $firstname=$_POST['firstname'];
                    $lastname=$_POST['lastname'];
                    $email=$_POST['email'];
                    $password=$_POST['password'];
                    if(!$firstname)
                    {
                        $errors[]="<p>Missing FirstName, Please Enter!</p>";
                    }
                    else
                    {
                        // $firstname=trim($firstname);
                        // $firstname=stripslashes($firstname);
                        // $firstname=htmlspecialchars($firstname);
                        $firstname=validInput($firstname);
                        echo $firstname;
                    }
                    if(!$lastname)
                    {
                        $errors[]="<p>Missing Lasttname, Please Enter!</p>";
                    }
                    else
                    {
                        // $lasttname=trim($lastname);
                        // $lasttname=stripslashes($lasttname);
                        // $lasttname=htmlspecialchars($lasttname);
                        $lastname=validInput($lastname);
                        echo $lastname;
                    }
                    if(!$email)
                    {
                        $errors[]="<p>Missing email, Please Enter!</p>";
                    }
                    else
                    {
                        $email=filter_var($email,FILTER_SANITIZE_EMAIL);
                        if(!filter_var($email,FILTER_VALIDATE_EMAIL))
                        {
                            $errors[]="<p>Invalide Email</p>";
                        }
                    }
                    if(!$password)
                    {
                        $errors[]="<p>Missing password, Please Enter!</p>";
                    }
                    $allErrors=join("<br",$errors);
                    if($errors)
                    {
                        $errorMesg='<div class="alert alert-danger">' . $allErrors . '</div>';
                        echo $errorMesg;
                    }
                    else
                    {
                        $tblname="Users";
                        $firstname=mysqli_real_escape_string($con,$firstname);
                        $lasttname=mysqli_real_escape_string($con,$lastname);
                        $email=mysqli_real_escape_string($con,$email);
                        $password=mysqli_real_escape_string($con,$password);
                        $password=md5($password);
                        //execute Query
                        if(!$_POST['id'])
                        {
                            $sql="INSERT INTO users(firstname,lastname,email,passwd) values('$firstname','$lastname','$email','$password')";
                        }
                        else
                        {
                            $sql="INSERT INTO users(id,firstname,lastname,email,passwd) values('$id','$firstname','$lastname','$email','$password')";
                        }
                        if(mysqli_query($con,$sql))
                        {
                            $resultMsg='<div class="alert alert-success"> Data added successfully into the table</div>';
                            echo $resultMsg;
                        }
                        else
                        {
                            $resultMsg='<div class="alert alert-danger"> Data not added  into the table' .$sql . '</div>';
                            echo $resultMsg;
                        }
                    }
                }
                function validInput($data)
                {
                    $data=trim($data);
                    $data=stripslashes($data);
                    $data=htmlspecialchars($data);
                    return $data;
                }
            ?>
           
        </div>
        <form class="row g-3" method="post">
            <div class="col-md-12">
                <label for="id" class="form-label">ID</label>
                <input type="text" class="form-control" name="id" placeholder="ID" maxlength="6">
            </div>
            <div class="col-6">
                <label for="firstname" class="form-label">First Name</label>
                <input type="text" class="form-control" name="firstname" placeholder="First Name" maxlength="30">
            </div>
            <div class="col-6">
                <label for="lastname" class="form-label">Last Name</label>
                <input type="text" class="form-control" name="lastname" placeholder="Last Name" maxlength="30">
            </div>
            <div class="col-md-6">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" placeholder="Email" maxlength="20">
            </div>
            <div class="col-md-6">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" placeholder="Password" maxlength="10">
            </div>
            
            
           
            <div class="col-12">
                <input type="submit" class="btn btn-primary" value="Send Data" name="submit"> 
            </div>
        </form>             
        
    </div>
</body>
</html>