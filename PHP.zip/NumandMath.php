<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Functions:Number & Math Function</title>
</head>
<body>
    <div class="container">
    <h1>Numbers and Math Function</h1>
    <div>
        <?php

        //Numeric Functions
       $x="6789";
       var_dump(is_numeric($x));
       echo "<br>";
       $x="67.89";
       var_dump(is_numeric($x));
       echo "<br>";
       $x="67.89" +100;
       var_dump(is_numeric($x));
       echo "<br>";
       $x="Hello";
       var_dump(is_numeric($x));
       echo "<br>";
       $x=56.99;
       $y=(int)$x;
       var_dump($y);
       echo "<br>";
       $x="56.99";
       $y=(int)$x;
       var_dump($y);
       echo "<br>";
       $x=acos(5);
       
       var_dump($x);
       echo "<br>";
       $x=1.9e422;
       
       var_dump(is_finite($x));
       echo "<br>";
       $x=56;
       
       var_dump(is_float($x));
       //Mathematical Functions
       echo "<br>";
       echo pi();
       echo "<br>";
       echo min(0,20,156,-23,-100);
       echo "<br>";
       echo max(0,20,156,-23,-100);
       echo "<br>";
       echo abs(-9.7);
       echo "<br>";
       echo sqrt(100);
       echo "<br>";
       echo round(5.6);
       echo "<br>";
       echo round(5.49);
       echo "<br>";
       echo rand(11,99);
        ?>
    </div>
    </div>
</body>
</html>