
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Courgette|Pacifico:400,700">
        <title>Upload File Using PHP</title>
       <style> 
       html{
        position: relative;
        min-height: 100%;
       }
    </style>
    </head>
    <body>
        <div class="container mt-5">
            <?php
                include "header.php";
                
            ?>
                        <div class="border border-success rounded p-3 mt-5 w-50">
                    <h3 class="text-primary text-center">Upload in PHP</h3>
                    <?php
                        $statusMsg='';
                        $targetDir="uploads/";
                        
                        if(isset($_POST['submit']) && !empty($_FILES['file']['name']))
                        {
                            $fileName=basename($_FILES['file']['name']);
                            $targetFile=$targetDir . $fileName;
                            $fileType=pathinfo($targetFile,PATHINFO_EXTENSION);
                            $fileTmpName=$_FILES['file']['tmp_name'];
                            $fileError=$_FILES['file']['error'];
                            $fileSize=$_FILES['file']['size'];

                            //allpwed file formats
                            $allowTypes=array('jpg','png','jpeg','gif','pdf','txt');
                            if(in_array($fileType,$allowTypes))
                            {
                                //check for file size
                                if($fileSize>1024*1024*5)
                                {
                                    $statusMsg='<div class="alert alert-danger">File is too Large Up to 5MB allowed</div>'; 
                                }
                                else
                                {
                                    //check file exists
                                    if(file_exists($targetFile))
                                    {
                                        $statusMsg='<div class="alert alert-danger">File already exists</div>';
                                    }
                                    else
                                    {
                                        //upload file to server
                                        if(move_uploaded_file($fileTmpName,$targetFile))
                                        {
                                            $statusMsg='<div class="alert alert-success">File ' . $fileName . ' uploaded successfully</div>';
                                        }
                                        else
                                        {
                                            $statusMsg='<div class="alert alert-danger">Sorry , Unable to upload File</div>'; 
                                        }
                                    }
                                }
                            }
                            else
                            {
                                $statusMsg='<div class="alert alert-danger">Sorry, Only JPG,PNG,JPEG,GIF,PDF and TXT files allowd</div>';  
                            }
                            
                        }
                        else
                        {
                            $statusMsg='<div class="alert alert-danger">Please select a file to upload</div>';

                        }
                        echo $statusMsg;
                    ?>
                    <form method="post" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ;?>"> 
                        <label for="file" class="form-lable mb-2">Select File to Upload</label>
                        <input type="file" name="file" id="file" placeholder="File" class="form-control mb-2">
                        <input type="submit" name="submit" value="Upload" class="btn btn-primary btn-lg mt-5">
                    </form>
                    
                </div>
                <?php
                include "footer.php";
            ?> 
        </div>
        <!-- JavaScript Bundle with Popper -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    </body>
</html>