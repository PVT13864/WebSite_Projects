<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Embend PHP in HTML</title>
</head>
<body>
  <h1>Embending PHP in HTML</h1>  
  <p>
    <?php
    echo "This is paragraph in P element"
    ?>
  </p>
  <?php
    echo "<p>This is paragraph in using PHP</p>"
    ?>
</body>
</html>