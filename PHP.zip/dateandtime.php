
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Courgette|Pacifico:400,700">
        <title>Date and Time PHP</title>
        
    </style>
    </head>
    <body>
        <div class="container ">
            <h1 class="text-center">Date and Time</h1>
                <div class="border border-success rounded p-3">
                    <h3 class="text-primary">Date using the date() function:</h3>
                        <?php
                        //Formatting the Dates and Times with PHP
                        // Day of the month:
                        //d (01/31)->two digits with leading zeros
                        //j (1/31)->without leading zeros
                        // Day of the week:
                        //D (Mon/Sun)->text as an abbreviation
                        //l (monday)->full lowercase
                        //L (MONDAY)->full uppercase
                        // Month:
                        //m (01/12)->two digits with leading zeros
                        //M (Jan)->text as an abbreviation
                        //F (January)-> Full month
                        // Year:
                        //y (09/15)->two digits
                        //Y (2009-2015)->Four Digits
                        // Separators:
                        //hyphens: (-)
                        //dots: (.)
                        //slashes: (/)
                        //spaces: ( )

                            $today=date("j F Y");
                            echo "<p> Date is :$today </>";
                        ?>
                    <h3 class="text-secondry">Time using the date() function:</h3>
                        <?php
                        //format the time string:
                        //hour:
                        //h (01-12)->12-hour format with leading zeros
                        //H (00-24)->24-hour format with leading zeros
                        //minutes:
                        //i (01-59)->minutes with leading zeros
                        //seconds:
                        //s (01-59) ->seconds with leading zeros
                        //Ante meridiem and Post meridiem
                        //a->lowercase
                        //A->uppercase

                            $today=date("H-i-s A");
                            echo "<p> Time is :$today </>";
                        ?>
                    <h3 class="text-success">Current timestamp using time() Function </h3>
                        <?php
                            $timestamp=time();
                            echo "<p> Timestamp :$timestamp </>";
                        ?>
                    <h3 class="text-info">Current timestamp using time</h3>
                        <?php
                                $timestamp=time();
                                $time=date("F d, y h:i:s A");
                                echo "<p> Time is :$time </>";
                            ?>
                    <h3 class="text-warning">Convert time to timestamp using mktime() function </h3>
                                <?php
                                    $timestamp=mktime(13,45,33,6,21,2024);
                                    echo "<p> Timestamp is :$timestamp </>";
                                    $time=date("F d, y h:i:s A",$timestamp);
                                    echo "<p> Time is :$time </>";
                                ?>
                    <h3 class="text-danger">Find out what day of the week you were born:</h3>
                            <?php
                                $timestamp=mktime(0,0,0,10,26,1975);
                                $time=date("l",$timestamp);
                                    echo "<p> You were born on :$time </>";
                            ?>
                    <h3 class="text-dark">Date in 1000 days from now:</h3>
                    <?php
                                $timestamp=mktime(0,0,0,date('m'),date('d')+1000,date('y'));
                                $time=date("D d M Y",$timestamp);
                                    echo "<p> Date after 1000 days will be  :$time </>";
                            ?>
                </div>
        </div>
        <!-- JavaScript Bundle with Popper -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    </body>
</html>