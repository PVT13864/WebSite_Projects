<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Iterations:For and foreach loop</title>
</head>
<body>
    <div class="container">
    <h1>For and foreach loop</h1>
    <div>
        <?php
        // echo "This line number 1 <br>";
        // echo "This line number 2<br>";
        // echo "This line number 3<br>";
       /* $x=1;
        while($x<=10)
        {
            echo "This line number $x <br>";
            $x+=1;
        }*/
        for($x=1;$x<=10;$x++)
        {
            echo "This line number $x <br>";
        }
        echo "<br><br>";
        /*$x=10;
        while($x<=100)
        {
            echo "This line number $x <br>";
            $x+=10;
        }*/
        echo "<br><br>";
        for($y=100;$y>0;$y-=10)
        {
            echo "This line number $y <br>";
        }
        //foreach loop
        echo "<br><br>";
        $color=array("red","pink","orange","yellow","green");
        foreach($color as $val)
        {
            echo "$val <br>";
        }
        ?>
    </div>
    </div>
</body>
</html>