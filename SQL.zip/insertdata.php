<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Insert data in table using PHP</title>
</head>
<body>
    <div class="container text-center">
        <h1>Insert data in table using PHP</h1>
        <?php
        $server="localhost";
        $user="root";
        $pw="";
        $DB="mydata";
        //create connection
            $con=new mysqli($server,$user,$pw,$DB);
            //check connection
            if($con->connect_error)
            {
                die("Connection Fail" . $con->connect_error);
            }
            echo '<div class="alert alert-success">Connection Successfull</div>';
            //insert data in table
            $sql="INSERT INTO  Users (firstname,lastname,email,passwd) VALUES('Ram','Verma','varmaram@gmail.com','1234');";
            $sql .="INSERT INTO  Users (firstname,lastname,email,passwd) VALUES('Amit ','Vashisht','vamit@gmail.com','amit123');";
            
            if($con->multi_query($sql)===true)
            {
                echo '<div class="alert alert-success">Inserted Row Successfully</div>';
            }
            else
            {
                echo '<div class="alert alert-danger">Error inserting table' . $sql . '</div>';
            }
            $con->close();
            echo '<div class="alert alert-danger">Connection closeed</div>';
        ?>
    </div>
</body>
</html>