<?php
    define('MYEMAIL','Your Email ID Here');
    define('MYPASS','Your Email Password Here');
?>