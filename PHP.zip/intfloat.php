<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Data Type:String</title>
</head>
<body>
    <div class="container">
    <h1>Data Type String</h1>
    <div>
        <?php
        $x=8;
        var_dump($x);
        echo "<br>";
        echo $x;
        $y=4;
        echo "<br>";
        echo $y;
        $z=$x+$y;
        echo "<br>";
        var_dump($z);
        $a=0x1A;
        echo "<br>";
        var_dump($a);
        $b=0123;
        echo "<br>";
        var_dump($b);
        $t=9.7;
        echo "<br>";
        var_dump($t);
        $w=$x+$t;
        echo "<br>";
        var_dump($w);
        echo "<br>";
        var_dump($t);

        ?>
    </div>
    </div>
</body>
</html>