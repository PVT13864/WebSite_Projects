<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Data Type:Object</title>
</head>
<body>
    <div class="container">
    <h1>Data Type Object</h1>
    <div>
        <?php
       class cars {
        //Properties
        public $make="Tata";
        private $status="off";
        //Method
        function turn_on()
        {
            $this->status="On";
        }
        function getStatus()
        {
            return $this->status;
        }
       }
       $newCar=new cars;
       var_dump($newCar);
       echo "<br>";
       echo $newCar->make;
       echo "<br>";
       echo $newCar->turn_on();
       echo "<br>";
       var_dump($newCar);
       echo "<br>";
       echo $newCar->getStatus()
        ?>
    </div>
    </div>
</body>
</html>