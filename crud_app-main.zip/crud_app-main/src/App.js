
import View_Data from "./components/view_component";

function App() {
  return (
    <>
        <div  className="container">
          <View_Data />
        </div>
     </>
  );
}

export default App;
