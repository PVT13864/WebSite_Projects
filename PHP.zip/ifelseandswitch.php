<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Condition:If .. Else and Switch Case</title>
</head>
<body>
    <div class="container">
    <h1>If .. Else and Switch Case</h1>
    <div>
        <?php
    $result=true;
    if($result)
    {
        echo "<p>You are not succesfull this Time</p>";
    }
    else
    {
        echo "<p>You are succesfull this Time</p>";
    }
   
    echo "<br>";
    $x=($result)? "A":"B";
    echo $x;
       $temp=10;
       if($temp<14)
       {
        echo "<p>Its cold weather outside</p>"; 
       } 
       elseif($temp>33)
       {
        echo "<p>Its very hot outside</p>";
       }
       else
       {
        echo "<p>Its a normal weather</p>";
       }

       $favColor="Red";
       switch($favColor)
       {
        case "Blue":
            echo "<p>My Fav. Color is $favColor </p>";
            break;
         case "Red":
            echo "<p>My Fav. Color is $favColor</p>";
            break;
        case "Orange":
            echo "<p>My Fav. Color is $favColor</p>";
            break;
        case "Pink":
            echo "<p>My Fav. Color is $favColor</p>";
            break;
        default:
        
            echo "<p>My Fav. Color is not in list</p>";
            break;
       }
        ?>
    </div>
    </div>
</body>
</html>