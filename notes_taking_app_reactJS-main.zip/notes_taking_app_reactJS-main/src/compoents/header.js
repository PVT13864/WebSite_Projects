
const Header = ()=>{
     return(<>
       <h1>Note App Clone</h1>
     </>)
}

export default Header