<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>PHP Filters</title>
</head>
<body>
    <div class="container">
    <h1>PHP Filters</h1>
    <h2 class="text-primary">Clean and Valid User Inputs</h2>
    <div>
        <?php 
        //username
        $userName='amit \kumar ';
        $userName=htmlspecialchars($userName);
        $userName=trim($userName);
        $userName=stripslashes($userName);
        echo $userName;
        //email
        echo "<br>";
        $myMail="parm@parminderpatial.tech";
        $myMail=filter_var($myMail,FILTER_VALIDATE_EMAIL);
       
        echo $myMail;
        echo "<br>";
        $myURL="ftpstyyty://www.google.co.in";
        $myURL=filter_var($myURL,FILTER_VALIDATE_URL);
        echo $myURL;
        ?>
       
    </div>

</div>
    </div>
</body>
</html>