<?php
                     $errors=[];
                     $errorMessage='';
                        if(isset($_POST["submit"]))
                        {
                            
                            //File Details
                            $name=$_FILES['file']['name'];
                            $type=$_FILES['file']['type'];
                            $tmp_name=$_FILES['file']['tmp_name'];
                            $fileError=$_FILES['file']['error'];
                            $size=$_FILES['file']['size'];
                            $target_dir="ftp://u461687377@81.16.28.77/domains/parminderpatial.tech/public_html/uploads";
                            $tmp_name=$target_dir . basename($tmp_name);
                            $tmp_name=strtolower(pathinfo($tmp_name,PATHINFO_EXTENSION));

                            //Allowed file type
                            $allowedType=array("text"=>"text/plain","pdf"=>"application/pdf");

                            //checks for files
                            if($fileError==4)
                            {
                                $errors[]="<p><strong>Please select the file to upload </strong></p>";
                            }
                            else
                            {
                                if(file_exists($target_dir))
                                {
                                    $errors[]="<p><strong>File already exists </strong></p>"; 
                                }
                            }
                            if($size>1024*1024*3)
                            {
                                $errors[]="<p><strong>File size is too large < 3MB </strong></p>"; 
                            }
                            if(!in_array($type,$allowedType))
                            {
                                $errors[]="<p><strong>Only PDF and Txt Files allowed</strong></p>"; 
                            }
                            $allErrors=join('<br',$errors);
                            if($errors)
                            {
                                
                                $errorMessage='<div class="alert alert-danger">' . $allErrors . '</div>';
                                echo $errorMessage;
                            }
                           else
                           {
                                if(move_uploaded_file($tmp_name,$target_dir))
                                {
                                    $errorMessage='<div class="alert alert-success"> File Uploaded succesfully </div>';
                                    echo $errorMessage;
                                }
                                else
                                {
                                    $errorMessage='<div class="alert alert-danger"> Unable to Upload File </div>';
                                    echo $errorMessage;
                                }
                           }
                           print_r($_FILES);
                           if($_FILES['file']['error']>0)
                           {
                                echo "<p> There is an error:" . $_FILES['file']['error'] . "</p>";
                           }
                           else
                           {
                                echo "<p> File:" . $_FILES['file']['name'] . "</p>";
                                echo "<p> File Type:" . $_FILES['file']['type'] . "</p>";
                                echo "<p> Temp location:" . $_FILES['file']['tmp_name'] . "</p>";
                                echo "<p> size:" . $_FILES['file']['size'] . "</p>";
                                echo "<p> File Destination:" ."uploads/" . $_FILES['file']['name'] . "</p>";
                           }
                        }
                            

                     ?>
                    