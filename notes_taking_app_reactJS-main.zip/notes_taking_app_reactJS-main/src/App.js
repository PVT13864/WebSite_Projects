
import Header from "./compoents/header";
import Notes from "./compoents/Notes";
function App() {
  return (
     <>
       <Header />
       <Notes />
       </>
  );
}

export default App;
