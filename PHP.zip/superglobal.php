<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>PHP Superglobals</title>
</head>
<body>
    <div class="container">
    <h1>Super Global: GET and POST</h1>
    <div>
        <?php 
        echo "<h3> Get Method</h3>";
       print_r($_GET);
       if($_GET["submit"])
       {
            if($_GET["username"])
            {
                echo "<p> Hi! " . $_GET["username"] . " Welcome to my page</p>";
            }
       }
       echo "<br>";
       echo "<h3> Post Method</h3>";
       print_r($_POST);
       if($_POST["submit"])
       {
        if($_POST["country"])
        {
            echo "<p> Your Country is  " . $_POST["country"] . " </p>";
        }
       }
        ?>
        <form method="get" action="superglobal.php">
    <label for="username">Username</label>
    <input type="text" name="username" id="username">
    <input type="submit" name="submit" value="Submit">
  </form>
  <form method="Post" action="superglobal.php">
    <label for="country">Country</label>
    <input type="text" name="country" id="country">
    <input type="submit" name="submit" value="Submit">
  </form>
    </div>
  
  
</div>
    </div>
</body>
</html>