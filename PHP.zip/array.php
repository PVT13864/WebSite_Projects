<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Data Type:Array</title>
</head>
<body>
    <div class="container">
    <h1>Data Type Array</h1>
    <div>
        <?php
        // Index Array
        $cars=array("Tata","Mahindra","Maruti");
        echo "<p>Indian Cars Makers</p>";
        print_r($cars);
        echo "<br>";
        echo $cars[1];
        //Associative Array
        /* Multiline line
        comment*/
        $shopList1=array("a"=>"Braed","b"=>"Milk","c"=>"Eggs");
        echo "<p>My Shoppling List</p>";
        print_r($shopList1);
        echo "<br>";
        var_dump($shopList1);
        $shopList2=array("b"=>"Milk","a"=>"Braed","c"=>"Eggs");
        echo "<p>shopList1==shopList2</p>";
       
        echo "<br>";
        var_dump($shopList1==$shopList2);
        echo "<br>";
        echo "<p>shopList1===shopList2</p>";
              
        var_dump($shopList1===$shopList2);
        echo "<br>";
        echo "<p>shopList1!=shopList2</p>";
              
        var_dump($shopList1!=$shopList2);
        $shopList3=array("d"=>"Curd","e"=>"Oat","f"=>"Butter");
        echo "<br>";
        echo "<p>shopList1+shopList3</p>";
              
        var_dump($shopList1+$shopList3);
        ?>
    </div>
    </div>
</body>
</html>