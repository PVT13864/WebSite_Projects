<?php
        $server="localhost";
        $user="root";
        $pw="";
        $DB="mydata";
        //create connection
            $con=new mysqli($server,$user,$pw,$DB);
            //check connection
            if($con->connect_error)
            {
                die("Connection Fail" . $con->connect_error);
            }
            echo '<p>Connection Successfull</p';