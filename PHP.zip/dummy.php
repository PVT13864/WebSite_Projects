<?php 
declare(strict_types=1);
function addNumbers(float $a, float $b) : float
{
    return $a + $b;
}
$c=AddNumbers(1.2,3.4);
var_dump($c);

?>