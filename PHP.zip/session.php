
<!DOCTYPE html>
<?php
    //start session 
    session_start();
?>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Courgette|Pacifico:400,700">
        <title>Session in PHP</title>
       <style> 
       html{
        position: relative;
        min-height: 100%;
       }
    </style>
    </head>
    <body>
        <div class="container mt-5">
            <?php
                include "header.php";
                
            ?>
                        <div class="border border-success rounded p-3 mt-5 w-50">
                    <h3 class="text-primary text-center">Session in PHP</h3>
                    <?php
                    $_SESSION['myColor']="Black";
                    $_SESSION['myCar']="HONDA";
                    echo "<br> Session variables set";
                    ?>
                    <?php
                        session_unset();
                        session_destroy();
                        echo "<br> Session variables unseset";
                    ?>
                </div>
                <?php
                include "footer.php";
            ?> 
        </div>
        <!-- JavaScript Bundle with Popper -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    </body>
</html>