<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Data Type:Null and Resource</title>
</head>
<body>
    <div class="container">
    <h1>Data Type Null and Resource</h1>
    <div>
        <?php
        // Null Data Type
        $nullVar=null;
        
        var_dump($nullVar);
        $x="Hello";
        echo "<br>";
        var_dump($x);
        $x=null;
        echo "<br>";
        var_dump($x);
         //Resource Data Type
         $myFile=fopen("Sample.txt","r");
         echo "<br>";
        var_dump($myFile);
        echo "<br>";
        echo fread($myFile,filesize("Sample.txt"));
        ?>
    </div>
    </div>
</body>
</html>