<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Functions</title>
</head>
<body>
    <div class="container">
    <h1>Functions</h1>
    <div>
        <?php 
        
        function writeMsg()
        {
            echo "Hello Using Function";
        }
        writeMsg();
        echo "<br>";
        function myFamily($fname)
        {
            echo "$fname Singh<br>";
        }
        myFamily("Ram");
        myFamily("Laxman");
        function myFamilyBirth($fname,$year)
        {
            echo "$fname Singh. Born in $year <br>";
        }
        myFamilyBirth("Ram","1976");
        myFamilyBirth("Laxman","1978");
        myFamilyBirth("Bharat",1977);
        function addNumbers(int $a,int $b)
        {
            return $a+$b;
        }
        echo addNumbers(5,"7");
        function addNumbers1(int $a,int $b)
        {
            return $a+$b;
        }
        echo addNumbers(5,"7");
        ?>
    </div>
    </div>
</body>
</html>